"""Serve NASA FIRMS MODIS and VIIRS active-fire detections as GeoJSON."""

import asyncio
import csv
import io
import logging
import math
import os
import sqlite3
import tempfile
import time as clock
import zlib
from contextlib import asynccontextmanager
from datetime import UTC, date, datetime, time, timedelta
from decimal import Decimal
from enum import Enum
from pathlib import Path
from typing import Annotated, Literal
from urllib.parse import quote

import httpx
from fastapi import FastAPI, HTTPException, Query, Request

from cache import BatchCache
from query_time import query_window, timezone

FIRMS_URL = "https://firms.modaps.eosdis.nasa.gov"
VIIRS_RANKS = {"l": 0, "n": 1, "h": 2}
VIIRS_CLASSES = {"l": "low", "n": "nominal", "h": "high"}
MAX_CSV_BYTES = 50 * 1024 * 1024
# The upstream API places the credential in the URL.
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)


class Source(str, Enum):
    MODIS_NRT = "MODIS_NRT"
    MODIS_SP = "MODIS_SP"
    VIIRS_NOAA20_NRT = "VIIRS_NOAA20_NRT"
    VIIRS_NOAA20_SP = "VIIRS_NOAA20_SP"
    VIIRS_NOAA21_NRT = "VIIRS_NOAA21_NRT"
    VIIRS_NOAA21_SP = "VIIRS_NOAA21_SP"
    VIIRS_SNPP_NRT = "VIIRS_SNPP_NRT"
    VIIRS_SNPP_SP = "VIIRS_SNPP_SP"


LIVE_SOURCES = [Source.MODIS_NRT, Source.VIIRS_NOAA20_NRT, Source.VIIRS_NOAA21_NRT]


class FIRMSFailure(Exception):
    """A sanitized upstream error safe to return to the caller."""


@asynccontextmanager
async def lifespan(app: FastAPI):
    key = os.environ.get("FIRMS_MAP_KEY", "").strip()
    if not key:
        raise RuntimeError("Set FIRMS_MAP_KEY before starting the service.")
    app.state.key = quote(key, safe="")
    default_path = Path(tempfile.gettempdir()) / "firms-hotspots" / "cache.sqlite3"
    app.state.cache = await asyncio.to_thread(
        BatchCache, Path(os.getenv("FIRMS_CACHE_PATH", str(default_path)))
    )
    app.state.batch_locks = [asyncio.Lock() for _ in range(64)]
    async with httpx.AsyncClient(
        base_url=FIRMS_URL,
        timeout=httpx.Timeout(30, connect=5),
        limits=httpx.Limits(max_connections=8),
        follow_redirects=False,
    ) as client:
        app.state.firms = client
        app.state.slots = asyncio.Semaphore(8)
        yield


app = FastAPI(title="FIRMS Hotspots", lifespan=lifespan)


async def fetch_csv(app: FastAPI, path: str) -> str:
    try:
        async with app.state.slots, asyncio.timeout(60):
            async with app.state.firms.stream("GET", path) as response:
                if response.status_code in (401, 403):
                    raise FIRMSFailure("FIRMS rejected the map key or access.")
                if response.status_code == 429:
                    raise FIRMSFailure("FIRMS rate limit reached.")
                if response.status_code != 200:
                    raise FIRMSFailure(f"FIRMS returned HTTP {response.status_code}.")
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    body.extend(chunk)
                    if len(body) > MAX_CSV_BYTES:
                        raise FIRMSFailure("FIRMS response exceeded 50 MiB. Use a smaller area or fewer days.")
        return body.decode("utf-8-sig")
    except (httpx.RequestError, TimeoutError):
        raise FIRMSFailure("FIRMS request failed or timed out.") from None
    except UnicodeError:
        raise FIRMSFailure("FIRMS returned invalid text encoding.") from None


def csv_rows(text: str, required: set[str]) -> csv.DictReader:
    rows = csv.DictReader(io.StringIO(text, newline=""), strict=True)
    if not required.issubset(rows.fieldnames or []):
        # FIRMS can return an error message as text with HTTP 200.
        raise FIRMSFailure("FIRMS did not return the expected CSV. Check your map key, quota and product dates.")
    return rows


def number(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed):
        raise ValueError("Non-finite value")
    return parsed


def optional_number(row: dict, name: str) -> float | None:
    value = (row.get(name) or "").strip()
    return number(value) if value else None


def parse_area(area: str) -> str:
    if area.strip().lower() == "world":
        return "world"
    try:
        west, south, east, north = map(number, area.split(","))
        if -180 <= west < east <= 180 and -90 <= south < north <= 90:
            return ",".join(format(Decimal(str(value or 0.0)), "f") for value in (west, south, east, north))
    except ValueError:
        pass
    raise HTTPException(422, "Use world or west,south,east,north with increasing bounds. Split areas crossing 180° into two queries.")


def parse_features(text: str, source: Source) -> list[dict]:
    required = {"latitude", "longitude", "acq_date", "acq_time", "satellite", "confidence"}
    features = []
    seen = set()
    is_modis = source.value.startswith("MODIS_")
    try:
        for row in csv_rows(text, required):
            lon, lat = number(row["longitude"]), number(row["latitude"])
            if not (-180 <= lon <= 180 and -90 <= lat <= 90):
                raise ValueError("Invalid coordinates")
            acq_date = date.fromisoformat(row["acq_date"])
            hhmm = row["acq_time"].strip().zfill(4)
            if not hhmm.isascii() or not hhmm.isdigit() or len(hhmm) != 4:
                raise ValueError("Invalid acquisition time")
            acquired = datetime.combine(acq_date, time(int(hhmm[:2]), int(hhmm[2:])), tzinfo=UTC)
            satellite = row["satellite"].strip()
            if not satellite:
                raise ValueError("Missing satellite")
            confidence = row["confidence"].strip().lower()
            if is_modis:
                confidence = int(confidence)
                if not 0 <= confidence <= 100:
                    raise ValueError("Invalid MODIS confidence")
            elif confidence not in VIIRS_RANKS:
                raise ValueError("Invalid VIIRS confidence")

            # Drop identical rows within this product and keep separate satellite observations.
            if None in row or any(value is None for value in row.values()):
                raise ValueError("Incomplete CSV row")
            row_key = tuple(row.items())
            if row_key in seen:
                continue
            seen.add(row_key)
            features.append({
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [lon, lat]},
                "properties": {
                    "source": source.value,
                    "sensor": "MODIS" if is_modis else "VIIRS",
                    "satellite": satellite,
                    "processing": "SP" if source.value.endswith("_SP") else "NRT",
                    "nominal_resolution_m": 1000 if is_modis else 375,
                    "acquired_at": acquired.isoformat().replace("+00:00", "Z"),
                    "confidence": confidence,
                    "confidence_scale": "0–100" if is_modis else "low/nominal/high",
                    "confidence_class": None if is_modis else VIIRS_CLASSES[confidence],
                    "frp_mw": optional_number(row, "frp"),
                    "scan_km": optional_number(row, "scan"),
                    "track_km": optional_number(row, "track"),
                    "brightness_k": optional_number(row, "brightness" if is_modis else "bright_ti4"),
                    "brightness_band": "MODIS channel 21/22" if is_modis else "VIIRS I-4",
                    "daynight": (row.get("daynight") or "").strip().upper() or None,
                    "fire_type_code": row.get("type") or None,
                    "version": row.get("version") or None,
                },
            })
    except (csv.Error, TypeError, AttributeError, ValueError, KeyError):
        raise FIRMSFailure("FIRMS returned malformed hotspot CSV.") from None
    return features


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/availability")
async def availability(request: Request):
    app = request.app
    try:
        text = await fetch_csv(app, f"/api/data_availability/csv/{app.state.key}/ALL")
        products = []
        allowed = {source.value for source in Source}
        for row in csv_rows(text, {"data_id", "min_date", "max_date"}):
            if row["data_id"] in allowed:
                products.append({
                    "source": row["data_id"],
                    "min_date": date.fromisoformat(row["min_date"]),
                    "max_date": date.fromisoformat(row["max_date"]),
                })
        return {"products": products}
    except FIRMSFailure as exc:
        raise HTTPException(502, str(exc)) from None
    except (csv.Error, TypeError, ValueError):
        raise HTTPException(502, "FIRMS returned malformed availability CSV.") from None


async def load_batch(app: FastAPI, product: Source, bounds: str, day: date, today: date):
    key = app.state.cache.key(product.value, bounds, day.isoformat())
    async with app.state.batch_locks[hash(key) % len(app.state.batch_locks)]:
        try:
            cached = await asyncio.to_thread(app.state.cache.get, key)
            if cached is not None:
                features, fetched = cached
                return features, fetched, True
        except (sqlite3.Error, ValueError, zlib.error):
            logging.warning("Could not read FIRMS cache; fetching from NASA.")

        path = f"/api/area/csv/{app.state.key}/{product.value}/{bounds}/1"
        if day != today or product.value.endswith("_SP"):
            path += f"/{day.isoformat()}"
        text = await fetch_csv(app, path)
        fetched = clock.time()
        features = await asyncio.to_thread(parse_features, text, product)
        # Keep a rolling-day request made across midnight out of the wrong cache entry.
        if any(feature["properties"]["acquired_at"][:10] != day.isoformat() for feature in features):
            raise FIRMSFailure("FIRMS returned data outside the requested UTC day; retry the query.")
        if day == today and datetime.fromtimestamp(fetched, UTC).date() != today:
            raise FIRMSFailure("The UTC day changed during retrieval; retry the query.")
        if product.value.endswith("_SP"):
            ttl = 7 * 86400
        elif day >= today - timedelta(days=1):
            ttl = 300
        else:
            ttl = 86400
        try:
            await asyncio.to_thread(app.state.cache.put, key, features, fetched, ttl)
        except sqlite3.Error:
            logging.warning("Could not write FIRMS cache; serving data from NASA.")
        return features, fetched, False


def filter_features(batches, lower, upper, zone, daynight, modis_min, viirs_min):
    features = []
    for batch in batches:
        for feature in batch:
            props = feature["properties"]
            acquired = datetime.fromisoformat(props["acquired_at"])
            if not lower <= acquired < upper:
                continue
            if daynight != "all" and props["daynight"] != {"day": "D", "night": "N"}[daynight]:
                continue
            confidence = props["confidence"]
            if props["sensor"] == "MODIS" and confidence < modis_min:
                continue
            if props["sensor"] == "VIIRS" and VIIRS_RANKS[confidence] < VIIRS_RANKS[viirs_min]:
                continue
            features.append({
                **feature,
                "properties": {**props, "acquired_at_local": acquired.astimezone(zone).isoformat()},
            })
    return features


@app.get("/hotspots")
async def hotspots(
    request: Request,
    area: Annotated[str, Query(max_length=100)],
    days: Annotated[int | None, Query(ge=1, le=31)] = None,
    start_date: date | None = None,
    start: Annotated[str | None, Query(max_length=40)] = None,
    end: Annotated[str | None, Query(max_length=40)] = None,
    tz: Annotated[str | None, Query(max_length=64)] = None,
    daynight: Literal["all", "day", "night"] = "all",
    source: Annotated[list[Source] | None, Query(max_length=8)] = None,
    modis_min_confidence: Annotated[int, Query(ge=0, le=100)] = 0,
    viirs_min_confidence: Annotated[str, Query(pattern="^[lnh]$")] = "l",
):
    bounds = parse_area(area)
    zone = timezone(tz)
    today = datetime.now(UTC).date()
    lower, upper, dates = query_window(start, end, start_date, days, zone, tz is not None, today)
    sources = list(dict.fromkeys(source or LIVE_SOURCES))
    if start_date is None and start is None and any(s.value.endswith("_SP") for s in sources):
        raise HTTPException(422, "Provide start_date or start and end for standard-processing products.")

    async def load_product(product: Source):
        batches = []
        fetched_at = []
        cache_hits = 0
        failures = []
        for day in dates:
            try:
                features, fetched, cached = await load_batch(request.app, product, bounds, day, today)
            except FIRMSFailure as exc:
                failures.append({"date": day.isoformat(), "detail": str(exc)})
                continue
            batches.append(features)
            fetched_at.append(fetched)
            cache_hits += cached
        selected = await asyncio.to_thread(
            filter_features, batches, lower, upper, zone, daynight, modis_min_confidence,
            viirs_min_confidence,
        )
        return selected, {
            "source": product.value,
            "status": ("partial" if batches else "error") if failures else "ok",
            "count": len(selected),
            "successful_days": len(batches),
            "cache_hits": cache_hits,
            "oldest_fetched_at": (
                datetime.fromtimestamp(min(fetched_at), UTC).isoformat() if fetched_at else None
            ),
            "failed_days": failures,
        }

    results = await asyncio.gather(*(load_product(product) for product in sources))
    reports = [report for _, report in results]
    if all(report["status"] == "error" for report in reports):
        raise HTTPException(502, detail={"sources": reports})

    features = [feature for batch, _ in results for feature in batch]
    features.sort(key=lambda feature: feature["properties"]["acquired_at"], reverse=True)
    return {
        "type": "FeatureCollection",
        "features": features,
        "count": len(features),
        "partial": any(report["status"] != "ok" for report in reports),
        "sources": reports,
        "window": {"start_utc": lower.isoformat(), "end_utc_exclusive": upper.isoformat(), "timezone": zone.key},
    }
